#include "pch.h"
#include <GL/glut.h>
#include <GL/gl.h> 
#include <iostream> 
#include <vector> 
#include <stdio.h>
#include <math.h>
#include <time.h>

using namespace std;
#define PI 3.14159265

typedef struct Punto {
	GLdouble x;
	GLdouble y;
};

typedef struct Poligono {
	vector< Punto > puntos;
	bool esCerrado;
	Punto centro;
};

double translacion[3][3] = {
   {1, 0, 0} ,
   {0, 1, 0} ,
   {0, 0, 1}
};

double escalar[3][3] = {
   {1, 0, 0} ,
   {0, 1, 0} ,
   {0, 0, 1}
};

double rotar[3][3] = {
   {1, 0, 0} ,
   {0, 1, 0} ,
   {0, 0, 1}
};

double ciza[3][3] = {
   {1, 0, 0} ,
   {0, 1, 0} ,
   {0, 0, 1}
};

double refleX[3][3] = {
   {1, 0, 0} ,
   {0, -1, 0} ,
   {0, 0, 1}
};

int WIDTH; int HEIGHT;
GLdouble coordenadaX, coordenadaY;
GLdouble coordenadaX2, coordenadaY2;
GLint origenX, origenY;
Poligono poli;
int contador = 0;
bool primerPunto, primeraLinea = false;
bool centro = false;

//Array de puntos
vector< Poligono > poligonos;
vector< Punto > v;

void bresenham();
void GoMenu(int x);
void trans(GLdouble x, GLdouble y, GLdouble centrox, GLdouble centroy, GLint id);

void inicio()
{
	/* Iniciar color fondo */
	glClear(GL_COLOR_BUFFER_BIT);
	glClearColor(0, 0, 0, 0.0);
	glPointSize(1);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(0, WIDTH, 0, HEIGHT);
	//Ejes de coordenadas
	glLineWidth(1);
	glColor3f(1.0, 1.0, 1.0);
	glBegin(GL_LINES);
	glVertex2i(origenX, HEIGHT);
	glVertex2i(origenX, 0);
	glEnd();
	glFlush();
	glBegin(GL_LINES);
	glVertex2i(0, origenY);
	glVertex2i(WIDTH, origenY);
	glEnd();
	glFlush();


}

vector< vector < double > > creaMatriz(GLint id) {
	vector< vector < double > > matriz;
	for (int i = 0; i < poligonos[id].puntos.size(); i++) {
		vector < double > aux;
		aux.push_back(poligonos[id].puntos[i].x);
		aux.push_back(poligonos[id].puntos[i].y);
		aux.push_back(1);
		matriz.push_back(aux);
	}
	return matriz;
}

void pintaLinea() {

	glBegin(GL_POINTS);
	for (int h = 0; h < v.size(); h++) {
		glVertex2d(v[h].x, v[h].y);
	}

	glEnd();
	glFlush();
}

void raton(int boton, int state, int x, int y) {

	if (boton == GLUT_LEFT_BUTTON && state == GLUT_DOWN && !primerPunto && !primeraLinea) {
		coordenadaX = x;
		coordenadaY = HEIGHT - y;
		Punto p;
		p.x = coordenadaX;
		p.y = coordenadaY;
		poli.puntos.push_back(p);
		primerPunto = true;

	}
	else if (boton == GLUT_LEFT_BUTTON && state == GLUT_DOWN && primerPunto && !primeraLinea) {
		coordenadaX2 = x;
		coordenadaY2 = HEIGHT - y;
		bresenham();
		Punto p;
		p.x = coordenadaX2;
		p.y = coordenadaY2;
		poli.puntos.push_back(p);
		primerPunto = false;
		primeraLinea = true;
	}
	else if (boton == GLUT_LEFT_BUTTON && state == GLUT_DOWN && primeraLinea) {
		coordenadaX = coordenadaX2;
		coordenadaY = coordenadaY2;
		coordenadaX2 = x;
		coordenadaY2 = HEIGHT - y;
		Punto p;
		p.x = coordenadaX2;
		p.y = coordenadaY2;
		poli.puntos.push_back(p);
		bresenham();

	}
	else if (boton == GLUT_RIGHT_BUTTON && state == GLUT_DOWN && !poli.puntos.empty()) {
		coordenadaX = x;
		coordenadaY = HEIGHT - y;
		Punto p;
		p.x = coordenadaX;
		p.y = coordenadaY;
		poli.puntos.push_back(p);
		poligonos.push_back(poli);
		bresenham();
		primeraLinea = false;
		centro = true;
		contador++;
		poli.puntos.clear();
	}
	else if (boton == GLUT_RIGHT_BUTTON && state == GLUT_DOWN && centro == true) {
		poligonos[poligonos.size() - 1].centro.x = x;
		poligonos[poligonos.size() - 1].centro.y = HEIGHT - y;
		printf("centro poligono: %f  ,  %f\n", poligonos[poligonos.size() - 1].centro.x, poligonos[poligonos.size() - 1].centro.y);
		centro = false;
	}
	else if (boton == GLUT_RIGHT_BUTTON && state == GLUT_DOWN && poli.puntos.empty() && centro == false) {
		GLint id;
		cout << "ID figura: " << endl;
		cin >> id;
		if (id < poligonos.size()) {
			poligonos[id].centro.x = x;
			poligonos[id].centro.y = y;
		}
		else {
			return;
		}
	}
}

double sign(double n) {
	if (n > 0) {
		return 1;
	}
	else if (n < 0) {
		return -1;
	}
	return 0;
}

void bresenham() {

	GLint x = coordenadaX;
	GLint y = coordenadaY;
	GLint dx = abs(coordenadaX2 - coordenadaX);
	GLint dy = abs(coordenadaY2 - coordenadaY);
	GLint s1 = sign(coordenadaX2 - coordenadaX);
	GLint s2 = sign(coordenadaY2 - coordenadaY);
	GLint flag;
	GLint temp;
	if (dy > dx) {
		temp = dx;
		dx = dy;
		dy = temp;
		flag = 1;
	}
	else {
		flag = 0;
	}

	int e = 2 * dy - dx;
	int i;
	Punto p;
	for (i = 1; i <= dx; i++)
	{
		//L -> P(x,y)
		p.x = x;
		p.y = y;
		v.push_back(p);

		while (e > 0) {
			if (flag == 1) {
				x = x + s1;
			}
			else {
				y = y + s2;
			}

			e = e - 2 * dx;
		}

		if (flag == 1) {
			y += s2;
		}
		else {
			x += s1;
		}
		e += 2 * dy;
	}

	p.x = coordenadaX2;
	p.y = coordenadaY2;
	v.push_back(p);

	if (coordenadaX > coordenadaX2) {
		reverse(v.begin(), v.end());
	}

	pintaLinea();
	v.clear();

}

void pintaPoligono(Poligono po) {
	for (int i = 0; i < po.puntos.size(); i++) {
		if (i < po.puntos.size() - 1) {
			coordenadaX = po.puntos[i].x;
			coordenadaY = po.puntos[i].y;
			coordenadaX2 = po.puntos[i + 1].x;
			coordenadaY2 = po.puntos[i + 1].y;
			bresenham();
		}
	}
}

void borraPoligono(int valor) {
	inicio();
	if (poligonos.size() > 0) {
		for (int i = 0; i < poligonos.size(); i++) {
			if (i != valor) {
				pintaPoligono(poligonos[i]);
			}
		}
	}
}

void cizalla(GLdouble x, GLdouble y, GLdouble centrox, GLdouble centroy, GLint id) {

	if (id > poligonos.size()) {
		return;
	}

	GLdouble vx = poligonos[id].centro.x, vy = poligonos[id].centro.y;
	trans(-vx, -vy, 0, 0, id);

	ciza[0][1] = x;
	ciza[1][0] = y;

	vector < vector < double > > nueva;
	vector < double > a;
	vector< vector < double > > matriz = creaMatriz(id);

	for (int i = 0; i < matriz.size(); i++) {
		for (int j = 0; j < 3; j++) {
			GLdouble d = ciza[j][0] * matriz[i][0] + ciza[j][1] * matriz[i][1] + ciza[j][2] * matriz[i][2];
			a.push_back(d);
		}
		nueva.push_back(a);
		a.clear();
	}

	Poligono k;
	Punto z;
	for (int i = 0; i < nueva.size(); i++) {
		z.x = nueva[i][0];
		z.y = nueva[i][1];
		k.puntos.push_back(z);
	}
	borraPoligono(id);
	pintaPoligono(k);
	k.centro.x = centrox;
	k.centro.y = centroy;
	poligonos[id] = k;
	trans(vx, vy, 0, 0, id);
}

void trans(GLdouble x, GLdouble y, GLdouble centrox, GLdouble centroy, GLint id) {

	if (id > poligonos.size()) {
		return;
	}

	translacion[0][2] = x;
	translacion[1][2] = y;

	vector < vector < double > > nueva;
	vector < double > a;
	vector< vector < double > > matriz = creaMatriz(id);

	for (int i = 0; i < matriz.size(); i++) {
		for (int j = 0; j < 3; j++) {
			GLdouble d = translacion[j][0] * matriz[i][0] + translacion[j][1] * matriz[i][1] + translacion[j][2] * matriz[i][2];
			a.push_back(d);
		}
		nueva.push_back(a);
		a.clear();
	}
	Poligono k;
	Punto z;
	for (int i = 0; i < nueva.size(); i++) {
		z.x = nueva[i][0];
		z.y = nueva[i][1];
		k.puntos.push_back(z);
	}
	borraPoligono(id);
	pintaPoligono(k);
	//Si viene del escalado no se cambia el centro de la figura
	if (centrox == 0 || centroy == 0) {
		k.centro.x = x;
		k.centro.y = y;
	}
	else {
		k.centro.x = centrox + x;
		k.centro.y = centroy + y;
	}
	poligonos[id] = k;
}

void escalado(GLdouble x, GLdouble y, GLint id) {

	if (id > poligonos.size()) {
		return;
	}

	GLdouble vx = poligonos[id].centro.x, vy = poligonos[id].centro.y;
	trans(-vx, -vy, 0, 0, id);


	escalar[0][0] = x;
	escalar[1][1] = y;

	vector < vector < double > > nueva;
	vector < double > a;
	vector< vector < double > > matriz = creaMatriz(id);

	for (int i = 0; i < matriz.size(); i++) {

		for (int j = 0; j < 3; j++) {
			GLdouble d = escalar[j][0] * matriz[i][0] + escalar[j][1] * matriz[i][1] + escalar[j][2] * matriz[i][2];
			a.push_back(d);
		}
		nueva.push_back(a);
		a.clear();


	}
	Poligono k;
	Punto z;
	for (int i = 0; i < nueva.size(); i++) {
		z.x = nueva[i][0];
		z.y = nueva[i][1];
		k.puntos.push_back(z);
	}
	borraPoligono(id);
	pintaPoligono(k);
	k.centro.x = vx;
	k.centro.y = vy;
	poligonos[id] = k;
	trans(vx, vy, 0, 0, id);
}

void rotacion(GLdouble alpha, GLdouble centrox, GLdouble centroy, GLint id)
{
	if (id > poligonos.size()) {
		return;
	}

	GLdouble vx = poligonos[id].centro.x, vy = poligonos[id].centro.y;
	trans(-vx, -vy, 0, 0, id);

	GLdouble aux = alpha * PI / 180;

	rotar[0][0] = cos(aux);
	rotar[1][1] = cos(aux);
	rotar[0][1] = -sin(aux);
	rotar[1][0] = sin(aux);

	vector < vector < double > > nueva;
	vector < double > a;
	vector< vector < double > > matriz = creaMatriz(id);

	for (int i = 0; i < matriz.size(); i++) {

		for (int j = 0; j < 3; j++) {
			GLdouble d = rotar[j][0] * matriz[i][0] + rotar[j][1] * matriz[i][1] + rotar[j][2] * matriz[i][2];
			a.push_back(d);
		}
		nueva.push_back(a);
		a.clear();


	}
	Poligono k;
	Punto z;
	for (int i = 0; i < nueva.size(); i++) {
		z.x = nueva[i][0];
		z.y = nueva[i][1];
		k.puntos.push_back(z);
	}
	borraPoligono(id);
	pintaPoligono(k);
	k.centro.x = centrox;
	k.centro.y = centroy;
	poligonos[id] = k;
	trans(vx, vy, 0, 0, id);
}

void reflexion(GLdouble m, GLdouble b, GLdouble centrox, GLdouble centroy, GLint id) {
	if (id > poligonos.size()) {
		return;
	}

	GLdouble vx = poligonos[id].centro.x, vy = poligonos[id].centro.y;
	trans(0, -b, 0, 0, id);

	GLdouble alpha = atan(m);
	refleX[0][0] = cos(2 * alpha);
	refleX[0][1] = sin(2 * alpha);
	refleX[1][0] = sin(2 * alpha);
	refleX[1][1] = -cos(2 * alpha);

	vector < vector < double > > nueva;
	vector < double > a;
	vector< vector < double > > matriz = creaMatriz(id);

	for (int i = 0; i < matriz.size(); i++) {

		for (int j = 0; j < 3; j++) {
			GLdouble d = refleX[j][0] * matriz[i][0] + refleX[j][1] * matriz[i][1] + refleX[j][2] * matriz[i][2];
			a.push_back(d);
		}
		nueva.push_back(a);
		a.clear();

	}
	Poligono k;
	Punto z;
	for (int i = 0; i < nueva.size(); i++) {
		z.x = nueva[i][0];
		z.y = nueva[i][1];
		k.puntos.push_back(z);
	}
	borraPoligono(id);
	pintaPoligono(k);
	poligonos[id] = k;
	trans(0, b, 0, 0, id);
}

void MyKeyboardFunc(unsigned char Key, int x, int y)
{

	GLdouble mx, my;
	GLdouble alpha;
	GLint id;
	GLdouble m, a;

	switch (Key) {
	case 'b':
		cout << "ID figura: " << endl;
		cin >> id;
		borraPoligono(id);
		poligonos.erase(poligonos.begin() + id);
		break;
	case 'B':
		cout << "ID figura: " << endl;
		cin >> id;
		borraPoligono(id);
		break;
	case 'X':
		cout << "Pendiente recta: " << endl;
		cin >> m;
		cout << "Desplazamiento del origen: " << endl;
		cin >> a;
		cout << "ID figura: " << endl;
		cin >> id;
		reflexion(m, a + origenY, poligonos[id].centro.x, poligonos[id].centro.y, id);
		break;
	case 'x':
		cout << "Pendiente recta: " << endl;
		cin >> m;
		cout << "Desplazamiento del origen: " << endl;
		cin >> a;
		cout << "ID figura: " << endl;
		cin >> id;
		reflexion(m, a + origenY, poligonos[id].centro.x, poligonos[id].centro.y, id);
		break;
	case 'C':
		printf("Cizalla x: \n");
		cin >> mx;
		printf("Cizalla y: \n");
		cin >> my;
		cout << "ID figura: " << endl;
		cin >> id;
		cizalla(mx, my, poligonos[id].centro.x, poligonos[id].centro.y, id);
		break;
	case 'c':
		printf("Cizalla x: \n");
		cin >> mx;
		printf("Cizalla y: \n");
		cin >> my;
		cout << "ID figura: " << endl;
		cin >> id;
		cizalla(mx, my, poligonos[id].centro.x, poligonos[id].centro.y, id);
		break;
	case 'R':
		printf("Grados de rotación: \n");
		cin >> alpha;
		cout << "ID figura: " << endl;
		cin >> id;
		rotacion(alpha, poligonos[id].centro.x, poligonos[id].centro.y, id);
		break;
	case 'r':
		printf("Grados de rotación: \n");
		cin >> alpha;
		cout << "ID figura: " << endl;
		cin >> id;
		rotacion(alpha, poligonos[id].centro.x, poligonos[id].centro.y, id);
		break;
	case 'E':
		cout << "Escalado X: " << endl;
		cin >> mx;
		printf("Escalado Y: \n");
		cin >> my;
		cout << "ID figura: " << endl;
		cin >> id;
		escalado(mx, my, id);
		break;
	case 'e':
		cout << "Escalado X: " << endl;
		cin >> mx;
		printf("Escalado Y: \n");
		cin >> my;
		cout << "ID figura: " << endl;
		cin >> id;
		escalado(mx, my, id);
		break;
	case 't':
		cout << "Translacion X: " << endl;
		cin >> mx;
		printf("Translacion Y: \n");
		cin >> my;
		printf("ID figura: \n");
		cin >> id;
		trans(mx, my, poligonos[id].centro.x, poligonos[id].centro.y, id);
		break;
	case 'T':
		cout << "Translacion X: " << endl;
		cin >> mx;
		printf("Translacion Y: \n");
		cin >> my;
		printf("ID figura: \n");
		cin >> id;
		trans(mx, my, poligonos[id].centro.x, poligonos[id].centro.y, id);
		break;
	case 27:
		exit(0);
		break;
	}
}

void creaMenu() {

	int sub1 = glutCreateMenu(GoMenu);
	glutAddMenuEntry("Rojo", 1);
	glutAddMenuEntry("Azul", 2);
	glutAddMenuEntry("Verde", 3);
	glutAddMenuEntry("Morado", 4);
	glutAddMenuEntry("Blanco", 5);
	glutAddMenuEntry("Naranja", 6);
	glutCreateMenu(GoMenu);
	glutAddSubMenu("Colores", sub1);
	glutAddMenuEntry("Borrar", 7);
	glutAddMenuEntry("Salir", 0);
	// attach the menu to the right button
	glutAttachMenu(GLUT_MIDDLE_BUTTON);
}

void GoMenu(int x) {

	GLdouble mx, my;
	GLdouble alpha;
	GLint id;
	GLdouble m, a;

	switch (x)
	{
	case 0:
		exit(0);
		break;
	case 1:
		printf("Color Rojo\n");
		glColor3f(1, 0.f, 0);
		break;
	case 2:
		printf("Color Azul\n");
		glColor3f(0.0, 0.0, 1.0);
		break;
	case 3:
		printf("Color Verde\n");
		glColor3f(0.0, 1.0, 0.0);
		break;
	case 4:
		printf("Color Morado\n");
		glColor3f(1, 0.0, 1.0);
		break;
	case 5:
		printf("Color Blanco\n");
		glColor3f(1.0, 1.0, 1.0);
		break;
	case 6:
		printf("Color Naranja\n");
		glColor3f(1.0, 0.5, 0.0);
		break;
	case 7:
		printf("Limpiado\n");
		inicio();
		poligonos.clear();
		break;
	}
}

void sleep(int s) {
	clock_t c;
	c = clock() + s * CLOCKS_PER_SEC;
	while (clock() < c) {}
}

void animacion() {
	Poligono aux;
	Punto punto;
	punto.x = 30;
	punto.y = 100;
	aux.puntos.push_back(punto);
	punto.x = 30;
	punto.y = 30;
	aux.puntos.push_back(punto);
	punto.x = 50;
	aux.puntos.push_back(punto);
	punto.x = 50;
	punto.y = 70;
	aux.puntos.push_back(punto);
	punto.x = 140;
	punto.y = 70;
	aux.puntos.push_back(punto);
	punto.x = 140;
	punto.y = 100;
	aux.puntos.push_back(punto);
	punto.x = 30;
	punto.y = 100;
	aux.puntos.push_back(punto);
	aux.centro.x = 30;
	aux.centro.y = 30;
	poligonos.push_back(aux);
	sleep(5);
	trans(0, 50, 30, 30, 0);
	sleep(1);
	aux.puntos.clear();
	sleep(1);
	punto.x = 150;
	punto.y = 95;
	aux.puntos.push_back(punto);
	punto.x = 150;
	punto.y = 75;
	aux.puntos.push_back(punto);
	punto.x = 170;
	punto.y = 85;
	aux.puntos.push_back(punto);
	punto.x = 150;
	punto.y = 95;
	aux.puntos.push_back(punto);
	aux.centro.x = 160;
	aux.centro.y = 85;
	poligonos.push_back(aux);
	trans(0, 50, 160, 85, 1);
	cizalla(0, 1, poligonos[0].centro.x, poligonos[0].centro.y, 0);
	aux.puntos.clear();
	sleep(1);
	trans(-20, 0, poligonos[0].centro.x, poligonos[0].centro.y, 0);
	punto.x = 700;
	punto.y = 30;
	aux.puntos.push_back(punto);
	punto.x = 725;
	punto.y = 70;
	aux.puntos.push_back(punto);
	punto.x = 750;
	punto.y = 30;
	aux.puntos.push_back(punto);
	punto.x = 725;
	punto.y = 70;
	aux.puntos.push_back(punto);
	punto.x = 725;
	punto.y = 140;
	aux.puntos.push_back(punto);
	punto.x = 740;
	punto.y = 140;
	aux.puntos.push_back(punto);
	punto.x = 740;
	punto.y = 170;
	aux.puntos.push_back(punto);
	punto.x = 710;
	punto.y = 170;
	aux.puntos.push_back(punto);
	punto.x = 710;
	punto.y = 140;
	aux.puntos.push_back(punto);
	punto.x = 725;
	punto.y = 140;
	aux.puntos.push_back(punto);
	punto.x = 725;
	punto.y = 110;
	aux.puntos.push_back(punto);
	punto.x = 710;
	punto.y = 85;
	aux.puntos.push_back(punto);
	punto.x = 725;
	punto.y = 110;
	aux.puntos.push_back(punto);
	punto.x = 740;
	punto.y = 85;
	aux.puntos.push_back(punto);
	aux.centro.x = 900;
	aux.centro.y = 400;
	poligonos.push_back(aux);
	aux.puntos.clear();
	punto.x = 930;
	punto.y = 430;
	aux.puntos.push_back(punto);
	punto.x = 900;
	punto.y = 350;
	aux.puntos.push_back(punto);
	punto.x = 860;
	punto.y = 350;
	aux.puntos.push_back(punto);
	punto.x = 850;
	punto.y = 400;
	aux.puntos.push_back(punto);
	punto.x = 870;
	punto.y = 450;
	aux.puntos.push_back(punto);
	punto.x = 930;
	punto.y = 430;
	aux.puntos.push_back(punto);
	aux.centro.x = 900;
	aux.centro.y = 400;
	poligonos.push_back(aux);

	aux.puntos.clear();
	punto.x = 830;
	punto.y = 390;
	aux.puntos.push_back(punto);
	punto.x = 800;
	punto.y = 380;
	aux.puntos.push_back(punto);
	aux.centro.x = 830;
	aux.centro.y = 390;
	poligonos.push_back(aux);
	aux.puntos.clear();
	punto.x = 850;
	punto.y = 340;
	aux.puntos.push_back(punto);
	punto.x = 830;
	punto.y = 320;
	aux.puntos.push_back(punto);
	aux.centro.x = 850;
	aux.centro.y = 340;
	poligonos.push_back(aux);

	aux.puntos.clear();
	trans(50, 0, 725, 30, 2);
	cizalla(0, -1, poligonos[0].centro.x, poligonos[0].centro.y, 0);
	sleep(1);
	int h = 0;
	for (int i = 0; i < 7; i++) {
		trans(-20, 0, poligonos[0].centro.x, poligonos[0].centro.y, 0);
		trans(-15, 0, poligonos[2].centro.x, poligonos[2].centro.y, 2);
		sleep(1);
	}
	for (int i = 0; i < 17; i++) {
		if (i == 16) {
			rotacion(-45, poligonos[2].centro.x, poligonos[2].centro.y, 2);
			borraPoligono(1);
			poligonos.erase(poligonos.begin() + 1);
		}
		else {
			if (h < 7) {
				escalado(1.1, 1, 4);
				escalado(1.1, 1, 5);
			}
			else {
				escalado(0.9, 1, 4);
				escalado(0.9, 1, 5);
			}
			rotacion(10, 900, 400, 3);
			trans(30, 0, poligonos[1].centro.x, poligonos[1].centro.y, 1);
			sleep(1);
			h++;
		}

	}
	sleep(1);
	rotacion(-45, poligonos[1].centro.x, poligonos[1].centro.y, 1);


}

int main(int argc, char** argv) {

	glutInit(&argc, argv);

	//Parametros para la ventana y el origen de coordenadas
	printf("Introduzca anchura: \n", argv[0]);
	scanf_s("%d", &WIDTH);
	printf("Introduzca altura: \n", argv[0]);
	scanf_s("%d", &HEIGHT);
	printf("Introduzca origen coordenadas X: \n", argv[0]);
	scanf_s("%d", &origenX);
	printf("Introduzca origen coordenadas Y: \n", argv[0]);
	scanf_s("%d", &origenY);

	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
	glutInitWindowSize(WIDTH, HEIGHT);
	glutCreateWindow("Transformaciones 2D");
	inicio();
	creaMenu();
	glutMouseFunc(raton);
	glutKeyboardFunc(MyKeyboardFunc);

	animacion();

	glutMainLoop();

	return 0;
}