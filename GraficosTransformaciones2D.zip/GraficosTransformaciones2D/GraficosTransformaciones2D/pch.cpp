// pch.cpp: el archivo de origen correspondiente al encabezado precompilado; es necesario para que la compilación se realice correctamente

#include "pch.h"

// En general, omita este archivo, pero consérvelo si utiliza encabezados precompilados.
