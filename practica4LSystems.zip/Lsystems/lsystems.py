#!/usr/bin/env python

import turtle

D = 90
L = 10

#Bucle para iterar
def iterar(axiom, num=0, initator='F'):

    def mover(actual, axiom):
        
        resultado = ''
        cons = {'+', '-', '[', ']'}
        for c in actual:
            if c in cons:
                resultado += c
                continue
            if c == 'F':
                resultado += axiom
        return resultado

    #Itera
    resultado = initator
    for i in xrange(0, num):
        #Traduce la regla
        resultado = mover(resultado, axiom)
    return resultado

def draw(axiom, d=D, l=L):

    stack  = []                
    canvas = turtle.Screen()
    x   = turtle.Turtle()

    x.hideturtle()          
    x.speed(0)              
    x.left(90)             

    for i in xrange(len(axiom)):
        c = axiom[i]

        if c == 'F':
            x.forward(l)

        if c == 'f':
            x.penup()
            x.forward(l)
            x.pendown()

        if c == '+':
            x.left(d)

        if c == '-':
            x.right(d)

        if c == '[':
            stack.append((x.heading(), x.pos()))

        if c == ']':
            heading, position = stack.pop()
            x.penup()
            x.goto(position)
            x.setheading(heading)
            x.pendown()

    canvas.onkey(canvas.bye, 'q')
    canvas.listen()
    turtle.mainloop()

if __name__ == '__main__':

    print("Introduce el L-system que quieres")
    tipo = input()

    if(tipo == 1):
        print("Pintando")
        axioma = "F-F+F+FF-F-F+F"
        axioma = iterar(axioma, 3, "F-F-F-F")
        draw(axioma, 60, 2)
    elif(tipo == 2):
        print("Curva de Koch")
        axioma = "F+F--F+F"
        axioma = iterar(axioma, 6, "F")
        draw(axioma, 60, 10)
    else:
        print("Pintando arbol")
        axiom = "F[-F]F[+F]F"
        axiom = iterar(axiom, 3, "F")
        draw(axiom, 60, 10)